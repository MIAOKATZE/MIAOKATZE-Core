// SPDX-License-Identifier: AGPL-3.0-only
package com.miaokatze.miaokatzecore.api.tooltip.component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.miaokatze.miaokatzecore.api.tooltip.TooltipArt;

/** One immutable table snapshot; units stay in their cells and every cell participates in layout. */
public final class TooltipTable implements TooltipBlock {

    public enum Alignment {
        LEFT,
        RIGHT
    }

    private final String title;
    private final List<String> headers;
    private final List<List<String>> rows;
    private final List<List<String>> measurementRows;
    private final List<Alignment> alignments;
    private final TooltipArt art;
    private final Map<String, TooltipInput> inputs;
    private final boolean keys;

    private TooltipTable(String title, List<String> headers, List<List<String>> rows, List<Alignment> alignments,
        TooltipArt art) {
        this(title, headers, rows, alignments, art, null, false);
    }

    private TooltipTable(String title, List<String> headers, List<List<String>> rows, List<Alignment> alignments,
        TooltipArt art, List<List<String>> measurementRows, boolean inputIcons) {
        this.title = cell(title);
        if (headers == null || headers.isEmpty() || headers.size() > 8)
            throw new IllegalArgumentException("1–8 table columns required");
        this.headers = cells(headers);
        if (rows == null || rows.isEmpty() || rows.size() > 128)
            throw new IllegalArgumentException("1–128 table rows required");
        List<List<String>> copy = new ArrayList<>();
        for (List<String> row : rows) {
            if (row == null || row.size() != headers.size())
                throw new IllegalArgumentException("Every row must have one cell per column");
            copy.add(cells(row));
        }
        this.rows = Collections.unmodifiableList(copy);
        this.measurementRows = measurementRows == null ? this.rows : measurementRows;
        this.alignments = Collections.unmodifiableList(new ArrayList<>(alignments));
        this.art = Objects.requireNonNull(art, "art");
        this.keys = inputIcons;
        Map<String, TooltipInput> parsed = new HashMap<>();
        for (List<String> row : this.measurementRows) {
            for (String value : row) {
                if (inputIcons && value.indexOf('[') >= 0) parsed.computeIfAbsent(value, TooltipInput::of);
                else if (TooltipInput.hasMaterial(value)) parsed.computeIfAbsent(value, TooltipInput::materials);
            }
        }
        this.inputs = parsed;
    }

    public static TooltipTable of(String title, List<String> headers, List<List<String>> rows) {
        List<Alignment> alignments = new ArrayList<>();
        for (int i = 0; i < headers.size(); i++) alignments.add(i == 0 ? Alignment.LEFT : Alignment.RIGHT);
        return new TooltipTable(title, headers, rows, alignments, TooltipArt.PLAIN);
    }

    /** Decorate explicit input labels in body cells; legacy tables keep literal brackets. */
    public TooltipTable withInputIcons() {
        return hasInputIcons() ? this : new TooltipTable(title, headers, rows, alignments, art, measurementRows, true);
    }

    public boolean hasInputIcons() {
        return keys;
    }

    public TooltipInput input(String value) {
        return inputs.get(value);
    }

    public TooltipTable withArt(TooltipArt art) {
        return new TooltipTable(title, headers, rows, alignments, art, measurementRows, hasInputIcons());
    }

    /** Stable column widths when the current variant displays only a subset of the possible rows. */
    public TooltipTable withMeasurementRows(List<List<String>> allRows) {
        List<List<String>> copy = new ArrayList<>(rows);
        for (List<String> row : allRows) {
            if (row.size() != headers.size()) throw new IllegalArgumentException("Measurement row width");
            copy.add(cells(row));
        }
        return new TooltipTable(
            title,
            headers,
            rows,
            alignments,
            art,
            Collections.unmodifiableList(copy),
            hasInputIcons());
    }

    public TooltipTable align(int column, Alignment alignment) {
        List<Alignment> next = new ArrayList<>(alignments);
        next.set(column, Objects.requireNonNull(alignment));
        return new TooltipTable(title, headers, rows, next, art, measurementRows, hasInputIcons());
    }

    public TooltipTable slice(int from, int to) {
        return new TooltipTable(
            title,
            headers,
            rows.subList(from, to),
            alignments,
            art,
            measurementRows,
            hasInputIcons());
    }

    public String title() {
        return title;
    }

    public List<String> headers() {
        return headers;
    }

    public List<List<String>> rows() {
        return rows;
    }

    /** Full immutable source rows remain the width basis across every pagination slice. */
    public List<List<String>> measurementRows() {
        return measurementRows;
    }

    public Alignment alignment(int column) {
        return alignments.get(column);
    }

    public TooltipArt art() {
        return art;
    }

    @Override
    public List<String> fallbackLines() {
        List<String> result = new ArrayList<>();
        if (!title.isEmpty()) result.add(TooltipInput.plainMaterials(title));
        for (List<String> row : rows) {
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < row.size(); i++) {
                if (i > 0) line.append("  |  ");
                TooltipInput input = input(row.get(i));
                line.append(TooltipInput.plainMaterials(headers.get(i)))
                    .append(": ")
                    .append(input == null ? row.get(i) : input.plain());
            }
            result.add(line.toString());
        }
        return Collections.unmodifiableList(result);
    }

    private static List<String> cells(List<String> source) {
        List<String> result = new ArrayList<>();
        for (String s : source) result.add(cell(s));
        return Collections.unmodifiableList(result);
    }

    private static String cell(String s) {
        Objects.requireNonNull(s, "table text");
        if (s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0 || s.length() > 2048)
            throw new IllegalArgumentException("Table cells must be single-line text up to 2048 characters");
        return s;
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, headers, rows, measurementRows, alignments, art, hasInputIcons());
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof TooltipTable)) return false;
        TooltipTable t = (TooltipTable) other;
        return title.equals(t.title) && headers.equals(t.headers)
            && rows.equals(t.rows)
            && measurementRows.equals(t.measurementRows)
            && alignments.equals(t.alignments)
            && art == t.art
            && hasInputIcons() == t.hasInputIcons();
    }
}
