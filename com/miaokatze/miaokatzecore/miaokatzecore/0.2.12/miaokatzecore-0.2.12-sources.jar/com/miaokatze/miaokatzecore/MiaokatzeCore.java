// SPDX-License-Identifier: AGPL-3.0-only
// Additional terms: see AGPL-ADDITIONAL-TERMS.md in the project root.

package com.miaokatze.miaokatzecore;

import com.miaokatze.miaokatzecore.api.recipe.RecipeRegistrationLifecycle;

import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLLoadCompleteEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

/**
 * Common entry point deliberately does not reference client or optional adapter classes.
 * The existing after:etfuturum / required-before:gregtech ordering addresses GT5U 5.09.54.205's preInit
 * read of EFR's blast furnace on the GTNH 2.9 RC baseline; it does not establish a fault's root cause.
 * This is independent of recipe scheduling. On GTNH/GT5U/EFR upgrades, review the call site and dependency
 * graph again. An equivalent upstream fix only makes this constraint redundant and reviewable for removal;
 * do not infer it from version numbers or silently ignore a dependency conflict.
 */
@Mod(
    modid = MiaokatzeCore.MODID,
    name = "MIAOKATZE Core",
    version = Tags.RELEASE_VERSION,
    acceptedMinecraftVersions = "[1.7.10]",
    dependencies = "required-before:gregtech;required-after:modularui2;required-after:gtnhlib;after:etfuturum")
public final class MiaokatzeCore {

    public static final String MODID = "miaokatzecore";

    @Mod.EventHandler
    public void serverStarting(cpw.mods.fml.common.event.FMLServerStartingEvent event) {
        com.miaokatze.miaokatzecore.bootstrap.LabBootstrap.serverStarting(event);
    }

    @Mod.EventHandler
    public void serverStopped(cpw.mods.fml.common.event.FMLServerStoppedEvent event) {
        com.miaokatze.miaokatzecore.api.testlab.LabEvents.clearAll();
    }

    @Mod.EventHandler
    public void loadComplete(FMLLoadCompleteEvent event) {
        RecipeRegistrationLifecycle.install(event.getSide());
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        if (!event.getSide()
            .isClient()) return;
        com.miaokatze.miaokatzecore.api.tooltip.TooltipPages.load(
            event.getModConfigurationDirectory()
                .toPath()
                .resolve("miaokatzecore/tooltip.properties"));
        try {
            Class.forName("com.miaokatze.miaokatzecore.client.items.TooltipInput")
                .getMethod("install")
                .invoke(null);
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Cannot install tooltip controls", exception);
        }
        if (!Loader.isModLoaded("NotEnoughItems")) return;
        try {
            // String lookup prevents optional NEI/client types from entering the common class's signatures.
            Class.forName("com.miaokatze.miaokatzecore.client.items.NEIItemOrdering")
                .getMethod("install")
                .invoke(null);
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Cannot install optional NEI item ordering", exception);
        }
    }
}
